// Slice the generated transparent atlas into individual sprites without changing its artwork.
const fs=require('node:fs'),zlib=require('node:zlib');
const path=require('node:path'),dir=path.join(__dirname,'dist','assets');
const png=fs.readFileSync(path.join(dir,'fruit-atlas.png'));
const width=png.readUInt32BE(16),height=png.readUInt32BE(20);
if(png[24]!==8||png[25]!==6)throw Error('Expected an 8-bit RGBA atlas.');
let offset=8,parts=[];
while(offset<png.length){const size=png.readUInt32BE(offset),type=png.toString('ascii',offset+4,offset+8);if(type==='IDAT')parts.push(png.subarray(offset+8,offset+8+size));offset+=size+12;}
const raw=zlib.inflateSync(Buffer.concat(parts)),stride=width*4,pixels=Buffer.alloc(stride*height);
function paeth(a,b,c){const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c}
for(let y=0;y<height;y++){const filter=raw[y*(stride+1)],base=y*stride;for(let x=0;x<stride;x++){const a=x>=4?pixels[base+x-4]:0,b=y?pixels[base-stride+x]:0,c=y&&x>=4?pixels[base-stride+x-4]:0,v=raw[y*(stride+1)+1+x];pixels[base+x]=(v+(filter===1?a:filter===2?b:filter===3?Math.floor((a+b)/2):filter===4?paeth(a,b,c):0))&255}}
const visited=new Uint8Array(width*height),queue=new Int32Array(width*height),components=[];
for(let p=0;p<width*height;p++){
  if(visited[p]||pixels[p*4+3]<35)continue;
  let head=0,tail=1,minX=width,minY=height,maxX=0,maxY=0;queue[0]=p;visited[p]=1;
  while(head<tail){const q=queue[head++],x=q%width,y=Math.floor(q/width);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);
    for(const n of [x?q-1:-1,x<width-1?q+1:-1,y?q-width:-1,y<height-1?q+width:-1]){if(n>=0&&!visited[n]&&pixels[n*4+3]>=35){visited[n]=1;queue[tail++]=n}}
  }
  if(tail>3000)components.push({x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1,pixels:tail});
}
components.sort((a,b)=>Math.floor((a.y+a.h/2)/(height/3))-Math.floor((b.y+b.h/2)/(height/3))||a.x-b.x);
if(components.length!==11)throw Error('Expected 11 sprites, found '+components.length);
let crcTable=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;crcTable[n]=c>>>0}
function crc(buffer){let c=0xffffffff;for(const b of buffer)c=crcTable[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0}
function chunk(type,data){const t=Buffer.from(type),result=Buffer.alloc(data.length+12);result.writeUInt32BE(data.length);t.copy(result,4);data.copy(result,8);result.writeUInt32BE(crc(Buffer.concat([t,data])),data.length+8);return result}
const names=['cherry','strawberry','grape','tangerine','orange','apple','pear','peach','pineapple','melon','watermelon'];
for(let i=0;i<components.length;i++){
  const b=components[i],padding=3,x=Math.max(0,b.x-padding),y=Math.max(0,b.y-padding),w=Math.min(width-x,b.w+padding*2),h=Math.min(height-y,b.h+padding*2);
  const ihdr=Buffer.alloc(13);ihdr.writeUInt32BE(w);ihdr.writeUInt32BE(h,4);ihdr[8]=8;ihdr[9]=6;
  const image=Buffer.alloc(h*(w*4+1));for(let row=0;row<h;row++)pixels.copy(image,row*(w*4+1)+1,(y+row)*stride+x*4,(y+row)*stride+(x+w)*4);
  fs.writeFileSync(path.join(dir,names[i]+'.png'),Buffer.concat([png.subarray(0,8),chunk('IHDR',ihdr),chunk('IDAT',zlib.deflateSync(image,{level:9})),chunk('IEND',Buffer.alloc(0))]));
}
console.log(JSON.stringify(components.map((b,i)=>({name:names[i],...b})),null,2));
