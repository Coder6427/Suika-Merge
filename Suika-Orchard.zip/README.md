# Suika Orchard

A fruit-merging browser game with eleven original, generated fruit illustrations. Drop matching fruit together to merge through the fruit family to a watermelon. Keep settled fruit below the dashed line. Matching watermelons clear for 100 bonus points.

The chibi edition uses softer pastel fruit mascots, springy impacts with squash and stretch, popping merge animations, and little chain celebrations. Physics runs in two smaller steps per frame, and a tiny contact tolerance lets visibly touching matching fruit merge reliably. Motion effects respect the browser's reduced-motion preference. Best scores from the original game are preserved.

## Play locally

With Node.js installed, run `node server.cjs`, then open http://127.0.0.1:4173. The `dist/` directory can also be served by any static host. No package installation or build step is needed.

Move the mouse and click to drop. On a touch screen, drag to aim and release to drop. Arrow keys aim, Space or Arrow Down drops, and P pauses. Sound, pause, instructions, and fresh-start controls are included. Personal best is saved in browser localStorage when available.

## Check gameplay

Run `node test-game.cjs` to check merging, chain reactions, collision constraints, cooldown, scoring, pause, overflow, watermelon completion, and reset.

## Assets and dependencies

Fruit illustrations were generated for this game, then extracted from the transparent atlas by `extract-assets.cjs`. The game uses Matter.js 0.20.0 (MIT license), vendored in `dist/assets/matter.min.js`. Fonts use Google Fonts with system font fallbacks. No other runtime network requests or accounts are needed by the game itself.

This is an original Suika-style implementation with original art and interface.
